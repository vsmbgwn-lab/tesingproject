# synergetics-gcp
This repo contains the resources related the GCP 
